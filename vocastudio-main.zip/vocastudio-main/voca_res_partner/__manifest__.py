{
    "name": "VOCA",
    "summary": """ """,
    "version": "0.1",
    "license": "LGPL-3",
    "author": "",
    "website": "",
    "depends": ["base",'website','crm','website_sale'],
    'auto_install': False,
    "data": [
        'views/res_partner_views.xml',
    ],
}
